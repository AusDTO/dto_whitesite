<h1 class="kss-title kss-title-main"Agency Whitesite</h1>

This is the front-end development CSS style guide for the design components built in Agency Whitesite theme for Drupal.

### Installation

Installation instructions for automatically building this style guide can be found in styleguide/README.md.
